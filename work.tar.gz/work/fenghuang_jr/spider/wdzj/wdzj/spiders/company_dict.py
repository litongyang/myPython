# __author__ = 'tongyang.li'
# -*- coding: utf-8 -*-

"""
构造公司字典
"""


class CompanyDict:
    def __init__(self):
        self.company_dict = {
            "翼龙贷": 144,
            "陆金所": 59
        }
