# __author__ = 'tongyang.li'
# -*- coding: utf-8 -*-
"""
log 配置
"""

import logging
from scrapy import log
from scrapy.utils.log import configure_logging

configure_logging(install_root_handler=False)
logging.basicConfig(
    filename='log.txt',
    format='%(levelname)s: %(message)s',
    level=logging.INFO
)


def info1(msg):
    logger = logging.getLogger('mycustomlogger')
    logger.warning(msg)


def warn(msg):
    log.msg(str(msg), level=log.WARNING)


def info(msg):
    log.msg(str(msg), level=log.INFO)


def debug(msg):
    log.msg(str(msg), level=log.DEBUG)
