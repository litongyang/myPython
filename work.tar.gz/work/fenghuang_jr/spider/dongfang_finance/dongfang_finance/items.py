# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.item import Item, Field


#  公司公告 item
class NoticeItem(scrapy.Item):
    company_code = Field()  # 公司编码
    company_name = Field()  # 公司名称
    notice_title = Field()  # 公告标题
    notice_type = Field()   # 公告类型
    notice_date = Field()  # 公告日期
