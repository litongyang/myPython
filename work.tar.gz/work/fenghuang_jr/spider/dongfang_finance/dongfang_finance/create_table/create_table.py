# __author__ = 'tongyang.li'
# -*- coding: utf-8 -*-

import MySQLdb


class CreateTable:
    def __init__(self):
        """
        self.db_name = 'spider'  # 数据库名,如果与现有数据库冲突，可改为其他名字
        self.db_host = '10.10.202.16'  # 主机名
        self.db_port = 3306  # 端口号
        self.username = 'root'  # 用户名
        self.password = '1234abcd'  # 密码
        """
        self.db_name = 'test'  # 数据库名,如果与现有数据库冲突，可改为其他名字
        self.db_host = 'localhost'  # 主机名
        self.db_port = 3306  # 端口号
        self.username = 'root'  # 用户名
        self.password = '123'  # 密码
        self.file_name = 'dongfang_test'

        self.conn = MySQLdb.connect(host=self.db_host, user=self.username, passwd=self.password, db=self.db_name,
                                    port=self.db_port)
        self.cur = self.conn.cursor()

    def create_table(self):
        try:
            self.cur.execute('set names \'utf8\'')
            self.cur.execute("drop table if exists %s" % self.file_name)
            self.cur.execute(
                "CREATE TABLE IF NOT EXISTS %s "
                "("
                "company_code varchar(50) comment '产品id',"
                "company_name varchar(50) comment '产品名称',"
                "notice_title varchar(100) comment '产品全称',"
                "notice_type varchar(50) comment '产品全称',"
                "notice_date varchar(30) comment '产品全称',"
                "notice_title_url varchar(2000) comment '产品全称',"
                "date varchar(30) comment '产品全称',"
                "PRIMARY KEY (`company_code`,`company_name`,`notice_title`,`notice_date`) )ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8"
                % self.file_name)
        except Exception, e:
            print Exception, e


if __name__ == '__main__':
    test = CreateTable()
    test.create_table()
