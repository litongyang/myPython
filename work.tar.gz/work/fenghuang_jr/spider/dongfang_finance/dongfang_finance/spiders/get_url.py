# __author__ = 'tongyang.li'
# -*- coding: utf-8 -*-

"""
 获取url
"""


class GetUrl:
    def __init__(self):
        self.page_len = 2
        self.url_head = 'http://data.eastmoney.com/Notice/Noticelist.aspx?type=0&market=all&date=&page='
        self.notice_url_list = []  # 公告url的list

    def get_notice_url(self):
        for i in range(1, self.page_len):
            url = str(self.url_head) + str(i)
            self.notice_url_list.append(url)
        for i in self.notice_url_list:
            print i
        return self.notice_url_list

if __name__ == '__main__':
    test = GetUrl()
    test.get_notice_url()



