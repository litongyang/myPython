use crm_v2;

drop table if exists tb_invest;
drop table if exists tb_invite_reward_trace;

drop table if exists crm_invest_status;
drop table if exists crm_invest_desc_status;
drop table if exists crm_invest_one_status;
