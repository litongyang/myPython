use crm_v2;

drop table if exists activity_contact_awards;