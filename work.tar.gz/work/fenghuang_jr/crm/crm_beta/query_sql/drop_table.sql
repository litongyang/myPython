use tmp;

drop table if exists activity_contact_awards;

--drop table if exists crm_fund_status_inc;
--drop table if exists crm_fund_desc_status_inc;
drop table if exists tb_invest;
drop table if exists tb_user;
drop table if exists tb_coupon_record_crm;
drop table if exists tb_invite_reward_trace;
--drop table if exists crm_coupon_desc_new_inc;
--drop table if exists crm_inc_new_user_all;


--drop table if exists crm_desc_json_old;
--drop table if exists crm_desc_json_diff;
--drop table if exists crm_desc_json_new;
--
drop table if exists crm_fund_status;
drop table if exists crm_fund_desc_status;
--
--drop table if exists crm_coupon_json_old;
--drop table if exists crm_coupon_json_new;
--drop table if exists crm_coupon_json_diff;
--
--drop table if exists crm_used_user_static;
--drop table if exists crm_used_user_exist;
--drop table if exists crm_used_user_blank;
