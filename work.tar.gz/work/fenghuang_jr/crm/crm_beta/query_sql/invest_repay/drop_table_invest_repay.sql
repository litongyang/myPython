use crm_v2;

drop table if exists invest_repay_logger;