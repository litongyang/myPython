# __author__ = 'tongyang.li'
# -*- coding: utf-8 -*-


def test():
    os =1
    cnt = 2
    return os,cnt


