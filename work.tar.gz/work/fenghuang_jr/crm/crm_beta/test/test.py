# __author__ = 'tongyang.li'
# -*- coding: utf-8 -*-

import test_data


def test1():
    os,cnt = test_data.test()
    print os
    print cnt

test1()
