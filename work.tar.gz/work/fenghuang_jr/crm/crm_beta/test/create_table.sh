#!/bin/sh
${HIVE_HOME}/bin/hive -f './query_sql/create_table.sql'