# __author__ = 'lty'
# -*- coding: utf-8 -*-

import json
import get_company_dict


class GetUrl:
    def __init__(self):
        self.news_url_file = open('news_url1.json', 'r')
        self.news_url_list = []
        self.news_time_list = []
        self.news_time_url_dict = {}  # 新闻的url和发表时间的映射字典
        self.company_news_url_head = 'http://stockhtm.finance.qq.com/astock/quotpage/news.htm?c=us'
        self.company_news_url_tail = '.OQ#'
        self.company_news_url_list = []

    """ 得到公司的新闻列表页 """
    def get_company_news_url(self):
        get_company_dict_class = get_company_dict.GetCompanyDict()
        company_code_list = get_company_dict_class.get_company_dict()
        for i in range(0, len(company_code_list)):
            url_tmp = self.company_news_url_head + company_code_list[i] + self.company_news_url_tail
            self.company_news_url_list.append(url_tmp)

    # def get_news_url_lately(self):

    def get_news_url(self):
        for line in self.news_url_file:
            json_data = eval(line)
        # json_data = json.load(self.news_url_file)
            for k, v in json_data.items():
                if k == str('news_url'):  # v:新闻的url:list
                    for i in range(0, len(v)):
                        self.news_url_list.append(v[i])
                if k == str('news_time'):
                    for i in range(0, len(v)):
                        self.news_time_list.append(v[i])
        # tmp = zip(self.news_url_list, self.news_time_list)
        # self.news_time_url_dict = dict((self.news_url_list, self.news_time_list) for self.news_url_list, self.news_time_list in tmp)
        # for k, v in self.news_time_url_dict.items():
        #     print k, v
        # print self.news_url_list[0]
        # self.news_url_file.close()
        return self.news_url_list

    def get_news_time_url_dict(self):
        for line in self.news_url_file:
            json_data = eval(line)
            # json_data = json.load(self.news_url_file)
            for k, v in json_data.items():
                if k == str('news_url'):  # v:新闻的url:list
                    for i in range(0, len(v)):
                        self.news_url_list.append(v[i])
                if k == str('news_time'):
                    for j in range(0, len(v)):
                        self.news_time_list.append(v[j])
        tmp = zip(self.news_url_list, self.news_time_list)
        self.news_time_url_dict = dict((self.news_url_list, self.news_time_list) for self.news_url_list, self.news_time_list in tmp)
        # for k, v in self.news_time_url_dict.items():
        #     print k, v
        return self.news_time_url_dict

if __name__ == '__main__':
    test = GetUrl()
    test.get_company_news_url()
    x = test.get_news_url()
    print len(x)
    test.get_news_time_url_dict()
