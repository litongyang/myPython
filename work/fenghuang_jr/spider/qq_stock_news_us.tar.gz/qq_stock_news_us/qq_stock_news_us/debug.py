# __author__ = 'tongyang.li'
"""
debug
"""

from scrapy.cmdline import execute
execute("scrapy crawl qq_stock_news_us1".split())
